﻿namespace _02___Classlib;

public class Class1
{

}
